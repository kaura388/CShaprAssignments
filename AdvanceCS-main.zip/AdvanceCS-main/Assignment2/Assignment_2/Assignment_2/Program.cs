﻿//FABIO DA MATA OLIVEIRA (3138693)
using Assignment_2;

var list1 = new Repository<T>();

Console.WriteLine(list1.Add(new T()));
Console.WriteLine(list1.Add(new T()));
Console.WriteLine(list1.Delete(new T()));
Console.WriteLine(list1.Update(new T(), new T()));

Console.WriteLine(list1.GetAll());

Console.ReadLine();