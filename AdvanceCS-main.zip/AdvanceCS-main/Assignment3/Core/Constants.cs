﻿namespace Core
{
    public enum Move
    {
        Up,
        Down,
        Left,
        Right
    }

    public enum CreatureType
    {
        Predator,
        Prey
    }
}
